import { Component, OnInit } from '@angular/core';
import { EventsService } from '../services/events.service';
import { CoursesService } from '../services/courses.service';
import { CourseCategoryService } from '../services/course-category.service';
declare var $;

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {
  eventDetails: any;
  courses: any;
  categoryType: any = 'all';
  courseType: any = 'all';
  eventType: any = 'all';
  eventLocation: any = 'all';
  courseCategory: any;

  constructor(
    private eventsService: EventsService,
    private coursesService: CoursesService,
    private courseCategoryService: CourseCategoryService,
  ) { }

  ngOnInit() {
    this.getCourseCategories();
    this.getEvents('all');
   // $('.custom-form').select2();
  }


  getEvents(courseid) {
    this.eventsService.getEventDetails(courseid)
      .subscribe((response) => {
        console.log(response);
        this.eventDetails = response['events']['data'];
        console.log(this.eventDetails);
      });
  }

  getCourseCategories() {
    this.courseCategoryService.getCourseCategories()
      .subscribe((response) => {
        this.courseCategory = response['courseCategory']['data'];
      })
  }

  getCourseByCategory() {
    this.courses = null;
    window.scroll(0, 0);
    var categoryId = this.categoryType;
    console.log(categoryId);
    this.coursesService.getCourseByCategory(categoryId)
      .subscribe(response => {
        this.courses = response['courses']['data'];
        console.log(this.courses);
      },
    err=>{
      console.log(err);
    })
  }

  searchEvents() {
    this.courseType;
    console.log(this.courseType);
    console.log(this.eventType);
    console.log(this.eventLocation);
    this.eventsService.filterEvents(this.courseType, this.eventType, this.eventLocation)
      .subscribe(response => {
        this.eventDetails = response['events']['data'];
        console.log(this.eventDetails);
      });
  }

}
