import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CourseCategoryService } from '../../services/course-category.service';
import { CoursesService } from '../../services/courses.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @ViewChild('dropdown') dropdown: ElementRef;
  courseCategory: any;
  courses: any;
  constructor(
    private courseCategoryService: CourseCategoryService,
    private coursesService: CoursesService
  ) { }

  ngOnInit() {
    this.getCourseCategories();
  }

  getCourseCategories() {
    this.courseCategoryService.getCourseCategories()
      .subscribe((response) => {
        this.courseCategory = response['courseCategory']['data'];
      })
  }

  getCourseByCategory(categoryId) {
    window.scroll(0, 0);
    this.coursesService.getCourseByCategory(categoryId)
      .subscribe(response => {
        this.courses = response['courses']['data'];
        console.log(this.courses);
      },
        err => {
          console.log(err);
        })
  }

  closeMenu(){
    var el = this.dropdown.nativeElement.click();
  }

}
