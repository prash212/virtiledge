import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {
  successMessage: any;
  constructor(
    private route: ActivatedRoute
  ) { }

  ngOnInit() {

    this.route.params.subscribe(params => {
      let page = params['page'];
      if (page == 'requestcallback') {
        this.successMessage = "Thank you for contacting us. We will reach you shortly.";
      }

    });
  }

}
