import { Component, OnInit } from '@angular/core';
import { CourseCategoryService } from '../services/course-category.service';
import { CoursesService } from '../services/courses.service';
import { ActivatedRoute } from '@angular/router';
declare var $;

@Component({
  selector: 'app-course-category',
  templateUrl: './course-category.component.html',
  styleUrls: ['./course-category.component.css']
})
export class CourseCategoryComponent implements OnInit {
  courseCategory: any;
  courses: any;
  selected_categoryid: any;
  constructor(
    private route: ActivatedRoute,
    private courseCategoryService: CourseCategoryService,
    private coursesService: CoursesService
  ) {

  }

  ngOnInit() {
    window.scroll(0, 0);
    this.getCourseCategories();
    $( ".bg-white.a" ).hover(
      function() {
        $( this ).append( $( ".test-course" ) );
      }
    );
  }

  getCourseCategories() {
    this.courseCategoryService.getCourseCategories()
      .subscribe((response) => {
        console.log(response);
        this.courseCategory = response['courseCategory']['data'];
        console.log(this.courseCategory);


        this.route.params.subscribe(params => {
          params['categoryid'];
          if (params['categoryid']!=0) {
            this.getCourseByCategory(params['categoryid']);
            this.selected_categoryid = params['categoryid'];
          } else {
            this.getCourseByCategory(this.courseCategory[0].cc_id_pk);
            this.selected_categoryid = this.courseCategory[0].cc_id_pk;
          }
        });


      })
  }

  getCourseByCategory(categoryId) {
    this.selected_categoryid = categoryId;
    this.courses = null;
    window.scroll(0, 0);
    this.coursesService.getCourseByCategory(categoryId)
      .subscribe(response => {
        this.courses = response['courses']['data'];
        console.log(this.courses);
      },
        err => {
          console.log(err);
        })
  }

}
