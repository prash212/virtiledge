import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reschedule-policy',
  templateUrl: './reschedule-policy.component.html',
  styleUrls: ['./reschedule-policy.component.css']
})
export class ReschedulePolicyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scroll(0, 0);
  }

}
