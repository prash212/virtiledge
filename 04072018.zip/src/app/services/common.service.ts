import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class CommonService {

  constructor(
    private http: HttpClient
  ) { }


  postRequestCallback(data) {
    data = JSON.stringify(data);
    return this.http.post("http://www.virtiledge.com/service/request_callback.php?action=insert", data);
  }

}
