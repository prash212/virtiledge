import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent implements OnInit {

  constructor(private meta: Meta, private titleService: Title) {
    this.titleService.setTitle('Virtiledge'); 
    this.meta.addTag({ name: 'description', content: 'test one'});
    this.meta.addTag({ name: 'keywords', content: 'test one, test two'});
  }

  ngOnInit() {
    window.scroll(0, 0);
  }

}
