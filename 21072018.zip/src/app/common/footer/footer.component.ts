import { Component, OnInit } from '@angular/core';
import { CoursesService } from '../../services/courses.service';
import { CommonService } from '../../services/common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  request: any = {};
  courses: any;
  constructor(
    private coursesService: CoursesService,
    private commonService: CommonService,
    private router: Router
  ) { }

  ngOnInit() {
    this.getCourses();
  }


  getCourses() {
    this.courses = null;
    window.scroll(0, 0);
    this.coursesService.getCourses()
      .subscribe(response => {
        this.courses = response['courses']['data'];
        console.log(this.courses);
      },
        err => {
          console.log(err);
        })
  }

  postRequestCallback() {
    console.log(this.request);
    this.commonService.postRequestCallback(this.request)
      .subscribe((response) => {
        console.log(response);
        this.router.navigate(['/success','requestcallback']);
      });
  }

}
