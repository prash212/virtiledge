import { Component, OnInit } from '@angular/core';
import { RegisterUserService } from '../services/register-user.service';
import { HomeComponent } from '../home/home.component';
import { Router } from '@angular/router';
import {
  AuthService,
  FacebookLoginProvider,
  GoogleLoginProvider
} from 'angular-6-social-login';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user: any = {};
  verifyEmailStatus:any = false;

  constructor(
    private registerUserService: RegisterUserService,
    private socialAuthService: AuthService,
    private router: Router,
    private loginService: LoginService
  ) { }

  ngOnInit() {
    window.scroll(0, 0);
  }

  register(user) {
    var _this = this;
    this.registerUserService.registerUser(user)
      .subscribe(function (response) {
        _this.router.navigate(['/success']);
      })
  }

  verifyEmail() {
    console.log(this.user.email);
    this.registerUserService.verifyEmail(this.user.email)
    .subscribe((response)=>{
      console.log(response['verifyEmail']['status']['type']);
      this.verifyEmailStatus = response['verifyEmail']['status']['type'];
    })
  }


  public socialSignIn(socialPlatform: string) {
    let socialPlatformProvider;
    if (socialPlatform == "facebook") {
      socialPlatformProvider = FacebookLoginProvider.PROVIDER_ID;
    } else if (socialPlatform == "google") {
      socialPlatformProvider = GoogleLoginProvider.PROVIDER_ID;
    }

    this.socialAuthService.signIn(socialPlatformProvider).then(
      (userData) => {
        console.log(socialPlatform + " sign in data : ", userData);
        // Now sign-in with userData
        // ...
        //this.router.navigate(['/student', userData]);

        this.loginService.login(userData)
          .subscribe((res) => {
            console.log(res);
            window.location.href = "http://virtiledge.com/student?idToken="+userData.token;
          })


      }
    );
  }

}
