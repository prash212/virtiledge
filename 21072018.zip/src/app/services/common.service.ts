import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class CommonService {
  url: any;
  constructor(
    private http: HttpClient
  ) {
    this.url = environment.serviceUrl;
  }


  postRequestCallback(data) {
    data = JSON.stringify(data);
    return this.http.post(this.url+"service/request_callback.php?action=insert", data);
  }

}
