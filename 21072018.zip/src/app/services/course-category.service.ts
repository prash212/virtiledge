import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class CourseCategoryService {
  url: any;
  constructor(
    private http:HttpClient
  ) { 
    this.url = environment.serviceUrl;
  }

  getCourseCategories(){
    return this.http.get(this.url+"service/course_category.php?action=select");
  }

}
