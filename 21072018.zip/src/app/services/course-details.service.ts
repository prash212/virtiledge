import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class CourseDetailsService {
  url: any;

  constructor(
    private http: HttpClient
  ) { 
    this.url = environment.serviceUrl;    
  }

  getCoursDetails(courseid){
    return this.http.get(this.url+"service/course-details.php?action=select&courseid="+courseid);
  }

}
