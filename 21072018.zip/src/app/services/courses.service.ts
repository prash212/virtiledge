import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class CoursesService {
  url: any;

  constructor(
    private http:HttpClient
  ) { 
    this.url = environment.serviceUrl;        
  }

  getCourses(){
    return this.http.get(this.url+"service/courses.php?action=select");
  }


  getCourseByCategory(categoryId){
    return this.http.get(this.url+"service/courses.php?action=select&categoryId="+categoryId);
  }

  getPopularCourses(){
    return this.http.get(this.url+"service/courses.php?action=select&type=popular");
  }

  searchCourses(keyword){
    return this.http.get(this.url+"service/courses.php?action=select&type=search&keyword="+keyword);
  }


}
