import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class EventsService {
  url: any;

  constructor(
    private http: HttpClient
  ) {
    this.url = environment.serviceUrl;            
   }

  getEventDetails(courseid) {
    return this.http.get(this.url+"service/events.php?action=select&courseid=" + courseid);
  }

  filterEvents(courseType, eventType, eventLocation) {
    return this.http.get(this.url+"service/events.php?action=select&type=filter&courseid=all&courseType=" + courseType + "&eventType=" + eventType + "&eventLocation=" + eventLocation);
  }

}
