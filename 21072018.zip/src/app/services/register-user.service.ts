import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class RegisterUserService {
  url: any;

  constructor(
    private http: HttpClient
  ) {
    this.url = environment.serviceUrl;                        
   }

  registerUser(user){
    user = JSON.stringify(user);
    return this.http.post(this.url+"service/user.php?action=insert",user)
  }

  verifyEmail(email){
    return this.http.post(this.url+"service/verify_email.php?action=select",{"email":email})
  }
}
