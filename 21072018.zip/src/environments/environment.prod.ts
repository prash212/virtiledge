export const environment = {
  production: true,
  serviceUrl: 'https://virtiledge.com/'
};
