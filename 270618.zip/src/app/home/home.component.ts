import { Component, OnInit } from '@angular/core';
import { CoursesService } from '../services/courses.service';
import { CourseCategoryService } from '../services/course-category.service';
declare var $;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  courses: any;
  keyword: any;
  searchCourse: any;
  courseCategory: any;
  constructor(
    private courseCategoryService: CourseCategoryService,
    private coursesService: CoursesService
  ) {
    this.getCourseCategories();
    this.getCourses();
  }

  ngOnInit() {

    window.scroll(0, 0);

    var substringMatcher = function(strs) {
      return function findMatches(q, cb) {
        var matches, substrRegex;
    
        // an array that will be populated with substring matches
        matches = [];
    
        // regex used to determine if a string contains the substring `q`
        substrRegex = new RegExp(q, 'i');
    
        // iterate through the pool of strings and for any string that
        // contains the substring `q`, add it to the `matches` array
        $.each(strs, function(i, str) {
          if (substrRegex.test(str)) {
            matches.push(str);
          }
        });
    
        cb(matches);
      };
    };
    
    var states = ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California',
      'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii',
      'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana',
      'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota',
      'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire',
      'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota',
      'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island',
      'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont',
      'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'
    ];
    
    $('#the-basics .typeahead').typeahead({
      hint: true,
      highlight: true,
      minLength: 1
    },
    {
      name: 'states',
      source: substringMatcher(states)
    });

    setTimeout(() => {

      $('.top-courses').owlCarousel({
        loop: true,
        autoplay: false,
        autoplayTimeout: 4000,
        navSpeed: 1000,
        dotsSpeed: 1000,
        dragEndSpeed: 1000,
        margin: 30,
        dots: false,
        nav: false,
        responsiveClass: true,
        responsive: {
          0: {
            items: 1
          },
          600: {
            items: 1
          },
          768: {
            items: 2
          },
          1000: {
            items: 4
          }
        }
      });
    }, 2000);

    $(window).load(function(){
      $('#page-preloader').fadeOut('fast',function(){$(this).remove();});
    });


    setTimeout(() => {

      $('.top-category').owlCarousel({
        loop: true,
        autoplay: false,
        autoplayTimeout: 4000,
        navSpeed: 1000,
        dotsSpeed: 1000,
        dragEndSpeed: 1000,
        autoWidth:true,
        dots: false,
        nav: false,
        margin:30,
        responsiveClass: true,
        responsive: {
          0: {
            items: 1
          },
          600: {
            items: 1
          },
          768: {
            items: 2
          },
          1000: {
            items: 4
          }
        }
      });
    }, 2000);


  }

  getCourses() {
    this.coursesService.getPopularCourses()
      .subscribe((response) => {
        console.log(response);
        this.courses = response['courses']['data'];
      });
  }

  searchCourses() {
    let keyword = this.keyword;
    console.log(keyword);
    if (keyword) {
      this.coursesService.searchCourses(keyword)
        .subscribe((response) => {
          console.log(response);
          this.searchCourse = response['courses']['data'];
        });
    } else {
      this.searchCourse = null;
    }
  }

  getCourseCategories() {
    this.courseCategoryService.getCourseCategories()
      .subscribe((response) => {
        this.courseCategory = response['courseCategory']['data'];
      })
  }

}
