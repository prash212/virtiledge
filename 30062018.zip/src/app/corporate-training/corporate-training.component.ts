import { Component, OnInit } from '@angular/core';
import { CourseCategoryService } from '../services/course-category.service';
import { CoursesService } from '../services/courses.service';
declare var $;

@Component({
  selector: 'app-corporate-training',
  templateUrl: './corporate-training.component.html',
  styleUrls: ['./corporate-training.component.css']
})
export class CorporateTrainingComponent implements OnInit {
  category_name: any;
  courseCategory: any;
  courses: any;
  constructor(
    private coursesService: CoursesService,
    private courseCategoryService: CourseCategoryService
  ) { }

  ngOnInit() {
    window.scroll(0, 0);

    setTimeout(() => {
      $('.offers').owlCarousel({
        loop: true,
        autoplay: true,
        autoplayTimeout: 4000,
        navSpeed: 1000,
        dotsSpeed: 1000,
        dragEndSpeed: 1000,
        margin: 30,
        dots: true,
        nav: false,
        responsiveClass: true,
        responsive: {
          0: {
            items: 1
          },
          600: {
            items: 1
          },
          768: {
            items: 2
          },
          1000: {
            items: 4
          }
        }
      });
    }, 2000);

    this.getCourseCategories();

  }


  getCourseCategories() {
    this.courseCategoryService.getCourseCategories()
      .subscribe((response) => {
        this.courseCategory = response['courseCategory']['data'];
      })
  }
  openPopup(categoryId, category_name){
      this.getCourseByCategory(categoryId,category_name);
  }
  closePopup(){
    this.courses = null;
  }

  getCourseByCategory(categoryId, category_name) {
    this.category_name = category_name;
    window.scroll(0, 0);
    console.log(categoryId);
    this.coursesService.getCourseByCategory(categoryId)
      .subscribe(response => {
        this.courses = response['courses']['data'];
      },
        err => {
          console.log(err);
        })
  }

}
