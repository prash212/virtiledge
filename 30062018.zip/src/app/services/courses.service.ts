import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class CoursesService {

  constructor(
    private http:HttpClient
  ) { }

  getCourses(){
    return this.http.get("http://www.virtiledge.com/service/courses.php?action=select");
  }


  getCourseByCategory(categoryId){
    return this.http.get("http://www.virtiledge.com/service/courses.php?action=select&categoryId="+categoryId);
  }

  getPopularCourses(){
    return this.http.get("http://www.virtiledge.com/service/courses.php?action=select&type=popular");
  }

  searchCourses(keyword){
    return this.http.get("http://www.virtiledge.com/service/courses.php?action=select&type=search&keyword="+keyword);
  }


}
