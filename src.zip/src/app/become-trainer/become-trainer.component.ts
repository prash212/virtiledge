import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-become-trainer',
  templateUrl: './become-trainer.component.html',
  styleUrls: ['./become-trainer.component.css']
})
export class BecomeTrainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scroll(0, 0);
  }

}
