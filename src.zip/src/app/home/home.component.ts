import { Component, OnInit } from '@angular/core';
import { CoursesService } from '../services/courses.service';
declare var $;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  courses: any;
  keyword: any;
  searchCourse:any;
  constructor(
    private coursesService: CoursesService
  ) {
    this.getCourses();
  }

  ngOnInit() {

    window.scroll(0, 0);

    setTimeout(() => {

      $('.top-courses').owlCarousel({
        loop: true,
        autoplay: true,
        autoplayTimeout: 4000,
        navSpeed: 1000,
        dotsSpeed: 1000,
        dragEndSpeed: 1000,
        margin: 30,
        dots: true,
        nav: false,
        responsiveClass: true,
        responsive: {
          0: {
            items: 1
          },
          600: {
            items: 1
          },
          768: {
            items: 2
          },
          1000: {
            items: 4
          }
        }
      });
    }, 2000);


  }

  getCourses() {
    this.coursesService.getPopularCourses()
      .subscribe((response) => {
        console.log(response);
        this.courses = response['courses']['data'];
      });
  }

  searchCourses() {
    let keyword = this.keyword;
    console.log(keyword);
    if (keyword) {
      this.coursesService.searchCourses(keyword)
        .subscribe((response) => {
          console.log(response);
          this.searchCourse = response['courses']['data'];
        });
    }else{
      this.searchCourse = null;
    }
  }

}
